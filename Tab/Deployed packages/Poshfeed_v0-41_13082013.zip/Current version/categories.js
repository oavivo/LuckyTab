var categoriesObj = {
	"geeky":{id:"geeky",display:"Geeky"},
	"intelectual": {id:"intelectual",display:"Intelectual"},
	"music": {id:"music",display:"Musicphile"},
	"food": {id:"food",display:"Foodie"},
	"art": {id:"art",display:"Artsy"},
	"cool": {id:"cool",display:"Cool"},
	"fashion": {id:"fashion",display:"Fashionable"}
}


